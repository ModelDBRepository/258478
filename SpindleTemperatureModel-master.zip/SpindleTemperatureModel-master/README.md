# Temperature Based Thalamic Network Model for Realistic Sleep Spindle Generation

This repository contains the codes related to our [thalamic network model](https://bartholab.github.io/SpindleTemperatureModel/).

To use this model you need a working installation of NEURON 7.3 and MATLAB 2016a+.


